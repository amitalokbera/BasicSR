# GENERATED VERSION FILE
# TIME: Wed Jun 26 10:50:13 2024
__version__ = '1.4.2'
__gitsha__ = '25765b2'
version_info = (1, 4, 2)
